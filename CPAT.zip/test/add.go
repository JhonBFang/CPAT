package test

// Add returns the sum of two integers.
func Add(a, b int) int {
	return a + b
}
